# Welcome to the ClickUp-Mail-Sync-Thunderbird-Addon wiki!

Configure the Add-on - [Please Read this](https://github.com/Ruvin/ClickUp-Mail-Sync-Thunderbird-Addon/wiki)

User-guide - [Please Read this](https://github.com/Ruvin/ClickUp-Mail-Sync-Thunderbird-Addon/wiki/User%E2%80%90guide)

